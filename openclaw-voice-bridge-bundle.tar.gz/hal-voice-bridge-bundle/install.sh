#!/usr/bin/env bash
set -euo pipefail

INSTALL_DIR="${INSTALL_DIR:-/opt/hal-voice-bridge}"
SERVICE_NAME="${SERVICE_NAME:-voice-bridge.service}"
LISTEN_HOST="${LISTEN_HOST:-127.0.0.1}"
LISTEN_PORT="${LISTEN_PORT:-8765}"
WYOMING_HOST="${WYOMING_HOST:-192.168.1.125}"
TTS_PORT="${TTS_PORT:-10200}"
STT_PORT="${STT_PORT:-10300}"
WAKE_PORT="${WAKE_PORT:-10400}"
DEFAULT_VOICE="${DEFAULT_VOICE:-en_US-hal_6409-medium}"
SYSTEMD_DIR="/etc/systemd/system"
SNIPPET_DIR="/etc/nginx/snippets"

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"

if [[ ${EUID} -ne 0 ]]; then
  echo "Please run as root." >&2
  exit 1
fi

mkdir -p "$INSTALL_DIR"
install -m 0644 "$SCRIPT_DIR/bridge.py" "$INSTALL_DIR/bridge.py"
install -m 0644 "$SCRIPT_DIR/openclaw_voice.user.js" "$INSTALL_DIR/openclaw_voice.user.js"
install -m 0644 "$SCRIPT_DIR/README.md" "$INSTALL_DIR/README.md"
install -m 0755 "$SCRIPT_DIR/uninstall.sh" "$INSTALL_DIR/uninstall.sh"

cat > "$SYSTEMD_DIR/$SERVICE_NAME" <<EOF
[Unit]
Description=Hal Voice Bridge
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=root
WorkingDirectory=$INSTALL_DIR
ExecStart=/usr/bin/python3 $INSTALL_DIR/bridge.py --listen-host $LISTEN_HOST --listen-port $LISTEN_PORT --wyoming-host $WYOMING_HOST --tts-port $TTS_PORT --stt-port $STT_PORT --wake-port $WAKE_PORT --default-voice $DEFAULT_VOICE
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable --now "$SERVICE_NAME"

mkdir -p "$SNIPPET_DIR"
cat > "$SNIPPET_DIR/voice-bridge.conf" <<EOF
location = /voice-bridge {
    return 301 /voice-bridge/;
}

location /voice-bridge/ {
    proxy_pass http://$LISTEN_HOST:$LISTEN_PORT/;
    proxy_http_version 1.1;
    proxy_set_header Host \$host;
    proxy_set_header X-Real-IP \$remote_addr;
    proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto \$scheme;
    proxy_read_timeout 3600s;
}
EOF

cat <<EOF

Installed bridge files into: $INSTALL_DIR
Systemd service: $SYSTEMD_DIR/$SERVICE_NAME
Nginx snippet:    $SNIPPET_DIR/voice-bridge.conf

Next nginx step:
1. Add this line inside your TLS server block:
      include snippets/voice-bridge.conf;
2. Test nginx:
      nginx -t
3. Reload nginx:
      systemctl reload nginx

Health check after nginx is wired:
  curl -k https://YOUR-HOST/voice-bridge/health

Userscript file for Tampermonkey:
  $INSTALL_DIR/openclaw_voice.user.js

Uninstall later with:
  $INSTALL_DIR/uninstall.sh
EOF
