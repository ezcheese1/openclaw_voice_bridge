#!/usr/bin/env python3
from __future__ import annotations

import argparse
import base64
import io
import json
import logging
import os
import socket
import wave
from dataclasses import dataclass
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any
from urllib.parse import parse_qs, urlparse


LOG = logging.getLogger("voice_bridge")


@dataclass(frozen=True)
class WyomingTarget:
    name: str
    host: str
    port: int


class BridgeError(Exception):
    def __init__(self, message: str, status: int = 400) -> None:
        super().__init__(message)
        self.status = status


class WyomingClient:
    def __init__(self, target: WyomingTarget, timeout: float = 15.0) -> None:
        self.target = target
        self.timeout = timeout

    def _connect(self) -> socket.socket:
        sock = socket.create_connection((self.target.host, self.target.port), timeout=self.timeout)
        sock.settimeout(self.timeout)
        return sock

    def _send_event(
        self,
        sock: socket.socket,
        event_type: str,
        data: dict[str, Any] | None = None,
        payload: bytes | None = None,
    ) -> None:
        header: dict[str, Any] = {"type": event_type}
        data_bytes = b""
        if data is not None:
            data_bytes = json.dumps(data).encode("utf-8")
            header["data_length"] = len(data_bytes)
        if payload is not None:
            header["payload_length"] = len(payload)
        sock.sendall(json.dumps(header).encode("utf-8") + b"\n" + data_bytes + (payload or b""))

    def _recv_exact(self, sock: socket.socket, size: int) -> bytes:
        chunks: list[bytes] = []
        remaining = size
        while remaining > 0:
            chunk = sock.recv(min(remaining, 65536))
            if not chunk:
                raise BridgeError(f"{self.target.name} closed the socket unexpectedly", status=502)
            chunks.append(chunk)
            remaining -= len(chunk)
        return b"".join(chunks)

    def _recv_event(self, sock: socket.socket) -> tuple[str, dict[str, Any], bytes]:
        header_line = b""
        while not header_line.endswith(b"\n"):
            chunk = sock.recv(1)
            if not chunk:
                raise BridgeError(f"{self.target.name} closed the socket before sending a header", status=502)
            header_line += chunk

        header = json.loads(header_line)
        data: dict[str, Any] = {}
        if header.get("data_length"):
            data = json.loads(self._recv_exact(sock, int(header["data_length"])).decode("utf-8"))

        payload = b""
        if header.get("payload_length"):
            payload = self._recv_exact(sock, int(header["payload_length"]))

        if isinstance(header.get("data"), dict):
            merged = dict(data)
            merged.update(header["data"])
            data = merged

        return str(header["type"]), data, payload

    def describe(self) -> dict[str, Any]:
        with self._connect() as sock:
            self._send_event(sock, "describe")
            event_type, data, _payload = self._recv_event(sock)
            if event_type == "error":
                raise BridgeError(data.get("text", f"{self.target.name} describe failed"), status=502)
            if event_type != "info":
                raise BridgeError(f"Unexpected {event_type!r} from {self.target.name} during describe", status=502)
            return data

    def synthesize(self, text: str, voice: dict[str, Any] | None = None) -> tuple[dict[str, Any], bytes]:
        payload = {"text": text}
        if voice:
            payload["voice"] = voice
        with self._connect() as sock:
            self._send_event(sock, "synthesize", payload)
            audio_info: dict[str, Any] | None = None
            chunks: list[bytes] = []
            while True:
                event_type, data, event_payload = self._recv_event(sock)
                if event_type == "error":
                    raise BridgeError(data.get("text", f"{self.target.name} synthesize failed"), status=502)
                if event_type == "audio-start":
                    audio_info = data
                    continue
                if event_type == "audio-chunk":
                    if audio_info is None:
                        audio_info = data
                    chunks.append(event_payload)
                    continue
                if event_type == "audio-stop":
                    break
            if not audio_info:
                raise BridgeError(f"{self.target.name} did not return audio metadata", status=502)
            return audio_info, b"".join(chunks)

    def transcribe(
        self,
        pcm: bytes,
        *,
        rate: int,
        width: int,
        channels: int,
        language: str | None = None,
        model: str | None = None,
        mode: str | None = None,
    ) -> dict[str, Any]:
        request: dict[str, Any] = {}
        if language:
            request["language"] = language
        if model:
            request["name"] = model
        if mode:
            request["mode"] = mode

        audio_meta = {"rate": rate, "width": width, "channels": channels}
        with self._connect() as sock:
            self._send_event(sock, "transcribe", request)
            self._send_event(sock, "audio-start", audio_meta)
            if pcm:
                self._send_event(sock, "audio-chunk", audio_meta, pcm)
            self._send_event(sock, "audio-stop")
            while True:
                event_type, data, _payload = self._recv_event(sock)
                if event_type == "error":
                    raise BridgeError(data.get("text", f"{self.target.name} transcribe failed"), status=502)
                if event_type == "transcript":
                    return data

    def detect_wake(
        self,
        pcm: bytes,
        *,
        rate: int,
        width: int,
        channels: int,
        names: list[str] | None = None,
    ) -> dict[str, Any]:
        request: dict[str, Any] = {}
        if names:
            request["names"] = names
        audio_meta = {"rate": rate, "width": width, "channels": channels}
        with self._connect() as sock:
            self._send_event(sock, "detect", request)
            self._send_event(sock, "audio-start", audio_meta)
            if pcm:
                self._send_event(sock, "audio-chunk", audio_meta, pcm)
            self._send_event(sock, "audio-stop")
            while True:
                event_type, data, _payload = self._recv_event(sock)
                if event_type == "error":
                    raise BridgeError(data.get("text", f"{self.target.name} wake detection failed"), status=502)
                if event_type == "detection":
                    out = dict(data)
                    out.setdefault("detected", True)
                    return out
                if event_type == "not-detected":
                    return {"detected": False}


def pcm_to_wav_bytes(pcm: bytes, *, rate: int, width: int, channels: int) -> bytes:
    out = io.BytesIO()
    with wave.open(out, "wb") as wav_file:
        wav_file.setnchannels(channels)
        wav_file.setsampwidth(width)
        wav_file.setframerate(rate)
        wav_file.writeframes(pcm)
    return out.getvalue()


def wav_bytes_to_pcm(wav_bytes: bytes) -> tuple[bytes, int, int, int]:
    with wave.open(io.BytesIO(wav_bytes), "rb") as wav_file:
        channels = wav_file.getnchannels()
        width = wav_file.getsampwidth()
        rate = wav_file.getframerate()
        pcm = wav_file.readframes(wav_file.getnframes())
    return pcm, rate, width, channels


def parse_audio_request(handler: BaseHTTPRequestHandler) -> tuple[bytes, int, int, int, dict[str, Any]]:
    content_length = int(handler.headers.get("Content-Length", "0") or 0)
    body = handler.rfile.read(content_length)
    content_type = (handler.headers.get("Content-Type") or "").split(";")[0].strip().lower()

    meta: dict[str, Any] = {}
    if content_type == "application/json":
        payload = json.loads(body.decode("utf-8")) if body else {}
        audio_b64 = payload.get("audio_base64")
        if not isinstance(audio_b64, str) or not audio_b64:
            raise BridgeError("JSON requests must include audio_base64", status=400)
        raw = base64.b64decode(audio_b64)
        audio_format = str(payload.get("audio_format", "wav")).lower()
        meta = payload
        if audio_format == "wav":
            pcm, rate, width, channels = wav_bytes_to_pcm(raw)
            return pcm, rate, width, channels, meta
        rate = int(payload["rate"])
        width = int(payload["width"])
        channels = int(payload["channels"])
        return raw, rate, width, channels, meta

    if content_type in {"audio/wav", "audio/x-wav", "audio/wave"}:
        pcm, rate, width, channels = wav_bytes_to_pcm(body)
        return pcm, rate, width, channels, meta

    if not body:
        raise BridgeError("Request body is empty", status=400)

    try:
        rate = int(handler.headers["X-Audio-Rate"])
        width = int(handler.headers.get("X-Audio-Width", "2"))
        channels = int(handler.headers.get("X-Audio-Channels", "1"))
    except KeyError as exc:
        raise BridgeError(f"Missing required header: {exc.args[0]}", status=400) from exc

    return body, rate, width, channels, meta


class VoiceBridgeHandler(BaseHTTPRequestHandler):
    server_version = "HalVoiceBridge/0.1"

    def log_message(self, format: str, *args: Any) -> None:  # noqa: A003
        LOG.info("%s - %s", self.address_string(), format % args)

    @property
    def bridge(self) -> "VoiceBridgeServer":
        return self.server  # type: ignore[return-value]

    def end_headers(self) -> None:
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, X-Audio-Rate, X-Audio-Width, X-Audio-Channels")
        super().end_headers()

    def do_OPTIONS(self) -> None:  # noqa: N802
        self.send_response(HTTPStatus.NO_CONTENT)
        self.end_headers()

    def do_GET(self) -> None:  # noqa: N802
        try:
            parsed = urlparse(self.path)
            if parsed.path == "/":
                self._json_response(200, {
                    "name": "Hal Voice Bridge",
                    "ok": True,
                    "default_voice": self.bridge.default_voice,
                    "endpoints": ["/health", "/describe", "/tts/voices", "/wake/models", "/tts", "/stt", "/wake/detect"],
                })
                return
            if parsed.path == "/health":
                self._json_response(200, self.bridge.health())
                return
            if parsed.path == "/describe":
                self._json_response(200, self.bridge.describe())
                return
            if parsed.path == "/tts/voices":
                self._json_response(200, self.bridge.tts_voices())
                return
            if parsed.path == "/wake/models":
                self._json_response(200, self.bridge.wake_models())
                return
            self._json_response(404, {"error": "not_found"})
        except BridgeError as exc:
            self._json_response(exc.status, {"error": str(exc)})
        except Exception as exc:  # noqa: BLE001
            LOG.exception("Unhandled GET error")
            self._json_response(500, {"error": str(exc)})

    def do_POST(self) -> None:  # noqa: N802
        try:
            parsed = urlparse(self.path)
            if parsed.path == "/tts":
                self._handle_tts()
                return
            if parsed.path in {"/stt", "/transcribe"}:
                self._handle_stt()
                return
            if parsed.path in {"/wake", "/wake/detect"}:
                self._handle_wake(parsed)
                return
            self._json_response(404, {"error": "not_found"})
        except BridgeError as exc:
            self._json_response(exc.status, {"error": str(exc)})
        except Exception as exc:  # noqa: BLE001
            LOG.exception("Unhandled POST error")
            self._json_response(500, {"error": str(exc)})

    def _handle_tts(self) -> None:
        content_length = int(self.headers.get("Content-Length", "0") or 0)
        payload = json.loads(self.rfile.read(content_length).decode("utf-8")) if content_length else {}
        text = payload.get("text")
        if not isinstance(text, str) or not text.strip():
            raise BridgeError("/tts requires JSON with a non-empty text field", status=400)

        voice_payload = payload.get("voice") if isinstance(payload.get("voice"), dict) else {}
        for key in ("name", "language", "speaker"):
            if key in payload and key not in voice_payload:
                voice_payload[key] = payload[key]

        if not voice_payload and self.bridge.default_voice:
            voice_payload = {"name": self.bridge.default_voice}

        audio_info, pcm = self.bridge.tts_client.synthesize(text=text, voice=voice_payload or None)
        wav_bytes = pcm_to_wav_bytes(
            pcm,
            rate=int(audio_info["rate"]),
            width=int(audio_info["width"]),
            channels=int(audio_info["channels"]),
        )

        self.send_response(200)
        self.send_header("Content-Type", "audio/wav")
        self.send_header("Content-Length", str(len(wav_bytes)))
        self.send_header("X-Audio-Rate", str(audio_info["rate"]))
        self.send_header("X-Audio-Width", str(audio_info["width"]))
        self.send_header("X-Audio-Channels", str(audio_info["channels"]))
        self.end_headers()
        self.wfile.write(wav_bytes)

    def _handle_stt(self) -> None:
        pcm, rate, width, channels, meta = parse_audio_request(self)
        transcript = self.bridge.stt_client.transcribe(
            pcm,
            rate=rate,
            width=width,
            channels=channels,
            language=self._first_non_empty(meta.get("language"), self.headers.get("X-Language")),
            model=self._first_non_empty(meta.get("model"), self.headers.get("X-Model-Name")),
            mode=self._first_non_empty(meta.get("mode"), self.headers.get("X-Mode"), "standard"),
        )
        transcript.update({"rate": rate, "width": width, "channels": channels})
        self._json_response(200, transcript)

    def _handle_wake(self, parsed) -> None:
        pcm, rate, width, channels, meta = parse_audio_request(self)
        query = parse_qs(parsed.query)
        names: list[str] = []
        if isinstance(meta.get("names"), list):
            names.extend(str(n) for n in meta["names"] if str(n).strip())
        if query.get("names"):
            names.extend(n.strip() for n in ",".join(query["names"]).split(",") if n.strip())
        result = self.bridge.wake_client.detect_wake(
            pcm,
            rate=rate,
            width=width,
            channels=channels,
            names=names or None,
        )
        result.update({"rate": rate, "width": width, "channels": channels, "requested_names": names})
        self._json_response(200, result)

    @staticmethod
    def _first_non_empty(*values: Any) -> str | None:
        for value in values:
            if isinstance(value, str) and value.strip():
                return value.strip()
        return None

    def _json_response(self, status: int, payload: dict[str, Any] | list[Any]) -> None:
        body = json.dumps(payload, indent=2).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


class VoiceBridgeServer(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(
        self,
        server_address: tuple[str, int],
        handler_class: type[BaseHTTPRequestHandler],
        *,
        tts_target: WyomingTarget,
        stt_target: WyomingTarget,
        wake_target: WyomingTarget,
        timeout: float,
        default_voice: str,
    ) -> None:
        super().__init__(server_address, handler_class)
        self.tts_client = WyomingClient(tts_target, timeout=timeout)
        self.stt_client = WyomingClient(stt_target, timeout=timeout)
        self.wake_client = WyomingClient(wake_target, timeout=timeout)
        self.default_voice = default_voice

    def describe(self) -> dict[str, Any]:
        return {
            "tts": self.tts_client.describe(),
            "stt": self.stt_client.describe(),
            "wake": self.wake_client.describe(),
        }

    def health(self) -> dict[str, Any]:
        report: dict[str, Any] = {"ok": True, "default_voice": self.default_voice, "services": {}}
        for name, client in (("tts", self.tts_client), ("stt", self.stt_client), ("wake", self.wake_client)):
            try:
                info = client.describe()
                report["services"][name] = {"ok": True, "host": client.target.host, "port": client.target.port, "info_keys": list(info.keys())}
            except Exception as exc:  # noqa: BLE001
                report["ok"] = False
                report["services"][name] = {"ok": False, "host": client.target.host, "port": client.target.port, "error": str(exc)}
        return report

    def tts_voices(self) -> dict[str, Any]:
        info = self.tts_client.describe()
        tts_entries = info.get("tts", [])
        if not tts_entries:
            return {"voices": []}
        return {"voices": tts_entries[0].get("voices", [])}

    def wake_models(self) -> dict[str, Any]:
        info = self.wake_client.describe()
        wake_entries = info.get("wake", [])
        if not wake_entries:
            return {"models": []}
        return {"models": wake_entries[0].get("models", [])}


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Tiny local HTTP bridge for Piper / faster-whisper / openWakeWord Wyoming services")
    parser.add_argument("--listen-host", default=os.getenv("VOICE_BRIDGE_LISTEN_HOST", "127.0.0.1"))
    parser.add_argument("--listen-port", type=int, default=int(os.getenv("VOICE_BRIDGE_LISTEN_PORT", "8765")))
    parser.add_argument("--wyoming-host", default=os.getenv("WYOMING_HOST", "192.168.1.125"))
    parser.add_argument("--tts-port", type=int, default=int(os.getenv("WYOMING_TTS_PORT", "10200")))
    parser.add_argument("--stt-port", type=int, default=int(os.getenv("WYOMING_STT_PORT", "10300")))
    parser.add_argument("--wake-port", type=int, default=int(os.getenv("WYOMING_WAKE_PORT", "10400")))
    parser.add_argument("--timeout", type=float, default=float(os.getenv("VOICE_BRIDGE_TIMEOUT", "20")))
    parser.add_argument("--default-voice", default=os.getenv("VOICE_BRIDGE_DEFAULT_VOICE", "en_US-hal_6409-medium"))
    parser.add_argument("--log-level", default=os.getenv("VOICE_BRIDGE_LOG_LEVEL", "INFO"))
    return parser


def main() -> None:
    parser = build_arg_parser()
    args = parser.parse_args()
    logging.basicConfig(level=getattr(logging, args.log_level.upper(), logging.INFO), format="%(asctime)s %(levelname)s %(name)s: %(message)s")

    server = VoiceBridgeServer(
        (args.listen_host, args.listen_port),
        VoiceBridgeHandler,
        tts_target=WyomingTarget("tts", args.wyoming_host, args.tts_port),
        stt_target=WyomingTarget("stt", args.wyoming_host, args.stt_port),
        wake_target=WyomingTarget("wake", args.wyoming_host, args.wake_port),
        timeout=args.timeout,
        default_voice=args.default_voice,
    )

    LOG.info(
        "voice bridge listening on http://%s:%s -> %s:%s/%s/%s",
        args.listen_host,
        args.listen_port,
        args.wyoming_host,
        args.tts_port,
        args.stt_port,
        args.wake_port,
    )
    LOG.info("default Piper voice: %s", args.default_voice)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        LOG.info("shutting down")
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
