#!/usr/bin/env bash
set -euo pipefail

INSTALL_DIR="${INSTALL_DIR:-/opt/hal-voice-bridge}"
SERVICE_NAME="${SERVICE_NAME:-voice-bridge.service}"
SYSTEMD_DIR="/etc/systemd/system"
SNIPPET_PATH="/etc/nginx/snippets/voice-bridge.conf"

if [[ ${EUID} -ne 0 ]]; then
  echo "Please run as root." >&2
  exit 1
fi

echo "Stopping and disabling ${SERVICE_NAME}..."
if systemctl list-unit-files | grep -q "^${SERVICE_NAME}\b"; then
  systemctl disable --now "$SERVICE_NAME" || true
fi

if [[ -f "$SYSTEMD_DIR/$SERVICE_NAME" ]]; then
  rm -f "$SYSTEMD_DIR/$SERVICE_NAME"
fi

systemctl daemon-reload
systemctl reset-failed || true

echo "Removing nginx snippet..."
rm -f "$SNIPPET_PATH"

echo "Removing install directory..."
rm -rf "$INSTALL_DIR"

cat <<EOF

Uninstall complete.

Removed:
- systemd service: $SYSTEMD_DIR/$SERVICE_NAME
- nginx snippet:  $SNIPPET_PATH
- install dir:     $INSTALL_DIR

If you had included the nginx snippet in a server block, remove this line manually:
  include snippets/voice-bridge.conf;

Then reload nginx:
  nginx -t && systemctl reload nginx
EOF
