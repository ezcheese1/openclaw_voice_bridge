# Hal Voice Bridge Bundle

This bundle packages the working voice loop into reusable install pieces:

- `bridge.py` — HTTP bridge for Piper / faster-whisper / openWakeWord Wyoming services
- `openclaw_voice.user.js` — Tampermonkey userscript for the OpenClaw Control UI
- `install.sh` — installs the bridge as a systemd service and writes an nginx snippet
- `uninstall.sh` — removes the installed service, nginx snippet, and install directory
- `voice-bridge.service.example` — reference service file
- `nginx-location.example.conf` — reference nginx location block

## What it gives you

- push-to-talk from the browser using the mouse back side button
- STT through faster-whisper
- spoken assistant replies through Piper
- stop speaking button
- shrink / minimize / restore controls
- same-origin bridge URL by default (`/voice-bridge`)

## Quick install

Run as root on the OpenClaw host:

```bash
cd hal-voice-bridge-bundle
chmod +x install.sh
./install.sh
```

Then include the nginx snippet in your TLS server block:

```nginx
include snippets/voice-bridge.conf;
```

And reload nginx:

```bash
nginx -t && systemctl reload nginx
```

## Uninstall

Run as root on the OpenClaw host:

```bash
/opt/hal-voice-bridge/uninstall.sh
```

That removes:
- the `voice-bridge.service`
- the nginx snippet at `/etc/nginx/snippets/voice-bridge.conf`
- the install directory `/opt/hal-voice-bridge`

If you added this include line to nginx, remove it manually from your server block before reloading nginx:

```nginx
include snippets/voice-bridge.conf;
```

## Default ports and voice

- Piper TTS: `192.168.1.125:10200`
- faster-whisper STT: `192.168.1.125:10300`
- openWakeWord: `192.168.1.125:10400`
- bridge listen: `127.0.0.1:8765`
- default voice: `en_US-hal_6409-medium`

## Override install values

You can override the defaults when running `install.sh`, for example:

```bash
DEFAULT_VOICE=en_US-hal_6409-medium \
WYOMING_HOST=192.168.1.125 \
LISTEN_PORT=8765 \
./install.sh
```

## Browser install

1. Install Tampermonkey in your browser.
2. Create a new userscript.
3. Paste in `openclaw_voice.user.js`.
4. Save and refresh the OpenClaw Control UI.

The userscript defaults to:

```text
window.location.origin + "/voice-bridge"
```

So it expects nginx to proxy `/voice-bridge/` on the same host as Control UI.
