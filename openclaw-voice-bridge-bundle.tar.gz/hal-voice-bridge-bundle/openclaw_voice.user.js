// ==UserScript==
// @name         OpenClaw Voice Bridge
// @namespace    hal.openclaw.voice
// @version      0.2.0
// @description  Speak assistant replies with Piper and send push-to-talk audio through the local voice bridge.
// @match        *://*/*
// @grant        none
// @run-at       document-idle
// ==/UserScript==

(function () {
  'use strict';

  const STORAGE_KEY = 'hal.voiceBridge.settings.v2';
  const PANEL_ID = 'hal-voice-bridge-panel';
  const STATUS_ID = 'hal-voice-bridge-status';
  const STATE_ID = 'hal-voice-bridge-state';
  const HOTKEY_LABEL = 'Mouse Back';
  const MOUSE_SIDE_BUTTON = 3; // Common "Back" side button

  const defaults = {
    bridgeUrl: `${window.location.origin}/voice-bridge`,
    voice: 'en_US-hal_6409-medium',
    autoSpeak: true,
    autoSend: true,
    panelMode: 'full', // full | compact | minimized
  };

  let settings = loadSettings();
  let panel = null;
  let statusEl = null;
  let stateEl = null;
  let pttButton = null;
  let shrinkButton = null;
  let minimizeButton = null;
  let playbackContext = null;
  let currentSource = null;
  let lastSpokenKey = '';
  let mediaStream = null;
  let currentMicLabel = '';
  let audioContext = null;
  let sourceNode = null;
  let processorNode = null;
  let silentGainNode = null;
  let recordedBuffers = [];
  let observer = null;
  let speakDebounce = null;
  let sideButtonRecording = false;
  let recordingActive = false;
  let stopRecordingPromise = null;
  let controlsInstalled = false;
  let pageObserver = null;
  let lastSubmittedSignature = '';
  let lastSubmittedAt = 0;

  function loadSettings() {
    try {
      return { ...defaults, ...JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}') };
    } catch {
      return { ...defaults };
    }
  }

  function saveSettings() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(settings));
  }

  function setState(mode, label = '') {
    if (!stateEl) return;
    stateEl.dataset.mode = mode;
    stateEl.textContent = label || mode;
    if (pttButton) {
      pttButton.classList.toggle('recording', mode === 'listening');
      pttButton.classList.toggle('busy', mode === 'transcribing' || mode === 'speaking');
    }
  }

  function setStatus(text, isError = false) {
    if (!statusEl) return;
    const message = text instanceof Error ? `${text.name}: ${text.message}` : String(text);
    statusEl.textContent = message;
    statusEl.title = message;
    statusEl.style.color = isError ? '#ff8e8e' : '#b7c9ff';
  }

  function normalizeBridgeUrl(url) {
    return (url || '').trim().replace(/\/$/, '');
  }

  function getTextarea() {
    return document.querySelector('.agent-chat__composer-combobox textarea, .agent-chat__input textarea, textarea');
  }

  function getSendButton() {
    return document.querySelector('.chat-send-btn:not(.chat-send-btn--stop)');
  }

  function setTextareaValue(text) {
    const textarea = getTextarea();
    if (!textarea) throw new Error('Could not find chat textarea');
    const setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value')?.set;
    if (setter) setter.call(textarea, text);
    else textarea.value = text;
    textarea.dispatchEvent(new Event('input', { bubbles: true }));
    textarea.dispatchEvent(new Event('change', { bubbles: true }));
    textarea.focus();
    return textarea;
  }

  function clearTextareaIfOwned(expectedText) {
    const textarea = getTextarea();
    if (!textarea) return;
    const current = (textarea.value || '').trim();
    if (current !== expectedText.trim()) return;
    const setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value')?.set;
    if (setter) setter.call(textarea, '');
    else textarea.value = '';
    textarea.dispatchEvent(new Event('input', { bubbles: true }));
    textarea.dispatchEvent(new Event('change', { bubbles: true }));
  }

  function sendText(text) {
    const trimmed = (text || '').trim();
    if (!trimmed) return;

    const signature = trimmed.toLowerCase();
    const now = Date.now();
    if (signature === lastSubmittedSignature && now - lastSubmittedAt < 2000) {
      setStatus('Skipped a duplicate send.');
      return;
    }
    lastSubmittedSignature = signature;
    lastSubmittedAt = now;

    setTextareaValue(trimmed);
    const cleanup = () => {
      window.setTimeout(() => clearTextareaIfOwned(trimmed), 150);
      window.setTimeout(() => clearTextareaIfOwned(trimmed), 700);
    };

    const button = getSendButton();
    if (button && !button.disabled) {
      button.click();
      cleanup();
      return;
    }
    const textarea = getTextarea();
    if (textarea) {
      textarea.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', bubbles: true }));
      cleanup();
    }
  }

  function getAssistantMessages() {
    return Array.from(document.querySelectorAll('.chat-group.assistant .chat-group-messages'));
  }

  function extractMessageText(group) {
    if (!group) return '';
    const textNodes = Array.from(group.querySelectorAll('.chat-text'));
    const parts = textNodes
      .map((node) => (node.innerText || node.textContent || '').trim())
      .filter(Boolean);
    return parts.join('\n\n').trim();
  }

  function getLatestAssistantPayload() {
    const groups = getAssistantMessages();
    for (let i = groups.length - 1; i >= 0; i -= 1) {
      const group = groups[i];
      const text = extractMessageText(group);
      if (!text) continue;
      const footer = group.querySelector('.chat-group-footer');
      const stamp = (footer?.innerText || '').trim();
      return { key: `${stamp}::${text}`, text };
    }
    return null;
  }

  function stopPlayback(updateUi = false) {
    if (currentSource) {
      try { currentSource.stop(); } catch {}
      try { currentSource.disconnect(); } catch {}
      currentSource = null;
    }
    if (updateUi) {
      setState('idle', 'Idle');
      setStatus('Speech stopped.');
    }
  }

  async function speakText(text, { force = false, key = null } = {}) {
    const trimmed = (text || '').trim();
    if (!trimmed) {
      setState('idle', 'Idle');
      setStatus('Nothing to speak yet.');
      return;
    }

    const speakKey = key || trimmed;
    if (!force && speakKey === lastSpokenKey) return;

    const bridgeUrl = normalizeBridgeUrl(settings.bridgeUrl);
    if (!bridgeUrl) throw new Error('Bridge URL is empty');

    setState('speaking', 'Speaking');
    setStatus('Requesting reply audio...');
    stopPlayback();

    const payload = { text: trimmed };
    if ((settings.voice || '').trim()) payload.name = settings.voice.trim();

    const response = await fetch(`${bridgeUrl}/tts`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });

    const contentType = response.headers.get('Content-Type') || '';
    if (!response.ok) {
      throw new Error(`TTS failed: ${response.status} ${await response.text()}`);
    }
    if (!contentType.toLowerCase().includes('audio/')) {
      const preview = (await response.text()).slice(0, 240);
      throw new Error(`TTS returned non-audio content-type: ${contentType || 'unknown'} :: ${preview}`);
    }

    const arrayBuffer = await response.arrayBuffer();
    if (!playbackContext || playbackContext.state === 'closed') {
      playbackContext = new (window.AudioContext || window.webkitAudioContext)();
    }
    if (playbackContext.state === 'suspended') {
      await playbackContext.resume();
    }

    const decoded = await playbackContext.decodeAudioData(arrayBuffer.slice(0));
    const source = playbackContext.createBufferSource();
    source.buffer = decoded;
    source.connect(playbackContext.destination);
    currentSource = source;
    lastSpokenKey = speakKey;
    source.onended = () => {
      if (currentSource === source) currentSource = null;
      try { source.disconnect(); } catch {}
      setState('idle', 'Idle');
      setStatus('Finished speaking.');
    };
    source.start();
    setStatus('Playing Piper reply...');
  }

  function downsampleBuffer(buffer, inputRate, outputRate) {
    if (outputRate === inputRate) return buffer;
    const ratio = inputRate / outputRate;
    const newLength = Math.round(buffer.length / ratio);
    const result = new Float32Array(newLength);
    let offsetResult = 0;
    let offsetBuffer = 0;
    while (offsetResult < result.length) {
      const nextOffsetBuffer = Math.round((offsetResult + 1) * ratio);
      let accum = 0;
      let count = 0;
      for (let i = offsetBuffer; i < nextOffsetBuffer && i < buffer.length; i += 1) {
        accum += buffer[i];
        count += 1;
      }
      result[offsetResult] = count ? accum / count : 0;
      offsetResult += 1;
      offsetBuffer = nextOffsetBuffer;
    }
    return result;
  }

  function encodeWav(samples, sampleRate, channels, bitsPerSample) {
    const blockAlign = channels * (bitsPerSample / 8);
    const byteRate = sampleRate * blockAlign;
    const dataSize = samples.length * 2;
    const buffer = new ArrayBuffer(44 + dataSize);
    const view = new DataView(buffer);
    writeString(view, 0, 'RIFF');
    view.setUint32(4, 36 + dataSize, true);
    writeString(view, 8, 'WAVE');
    writeString(view, 12, 'fmt ');
    view.setUint32(16, 16, true);
    view.setUint16(20, 1, true);
    view.setUint16(22, channels, true);
    view.setUint32(24, sampleRate, true);
    view.setUint32(28, byteRate, true);
    view.setUint16(32, blockAlign, true);
    view.setUint16(34, bitsPerSample, true);
    writeString(view, 36, 'data');
    view.setUint32(40, dataSize, true);
    floatTo16BitPCM(view, 44, samples);
    return new Blob([buffer], { type: 'audio/wav' });
  }

  function writeString(view, offset, string) {
    for (let i = 0; i < string.length; i += 1) {
      view.setUint8(offset + i, string.charCodeAt(i));
    }
  }

  function floatTo16BitPCM(view, offset, input) {
    for (let i = 0; i < input.length; i += 1, offset += 2) {
      const s = Math.max(-1, Math.min(1, input[i]));
      view.setInt16(offset, s < 0 ? s * 0x8000 : s * 0x7fff, true);
    }
  }

  async function transcribeWavBlob(wavBlob) {
    const bridgeUrl = normalizeBridgeUrl(settings.bridgeUrl);
    if (!bridgeUrl) throw new Error('Bridge URL is empty');
    setState('transcribing', 'Transcribing');
    setStatus('Transcribing microphone audio...');
    const response = await fetch(`${bridgeUrl}/stt`, {
      method: 'POST',
      headers: { 'Content-Type': 'audio/wav' },
      body: wavBlob,
    });
    if (!response.ok) {
      throw new Error(`STT failed: ${response.status} ${await response.text()}`);
    }
    return response.json();
  }

  function mergeBuffers(buffers) {
    const totalLength = buffers.reduce((sum, buf) => sum + buf.length, 0);
    const result = new Float32Array(totalLength);
    let offset = 0;
    for (const buf of buffers) {
      result.set(buf, offset);
      offset += buf.length;
    }
    return result;
  }

  function computePeak(samples) {
    let peak = 0;
    for (let i = 0; i < samples.length; i += 1) {
      const v = Math.abs(samples[i]);
      if (v > peak) peak = v;
    }
    return peak;
  }

  async function startRecording() {
    if (recordingActive || mediaStream) return;
    recordingActive = true;

    const stream = await navigator.mediaDevices.getUserMedia({
      audio: {
        echoCancellation: true,
        noiseSuppression: true,
        autoGainControl: true,
        channelCount: 1,
      },
    });
    mediaStream = stream;
    currentMicLabel = stream.getAudioTracks()[0]?.label || 'unknown microphone';
    recordedBuffers = [];

    audioContext = new (window.AudioContext || window.webkitAudioContext)();
    if (audioContext.state === 'suspended') {
      await audioContext.resume();
    }
    sourceNode = audioContext.createMediaStreamSource(stream);
    processorNode = audioContext.createScriptProcessor(4096, 1, 1);
    silentGainNode = audioContext.createGain();
    silentGainNode.gain.value = 0;
    processorNode.onaudioprocess = (event) => {
      const input = event.inputBuffer.getChannelData(0);
      recordedBuffers.push(new Float32Array(input));
    };
    sourceNode.connect(processorNode);
    processorNode.connect(silentGainNode);
    silentGainNode.connect(audioContext.destination);
    setState('listening', 'Listening');
    setStatus(`Listening on ${currentMicLabel}. Release ${HOTKEY_LABEL} or the button when you're done.`);
  }

  async function stopRecording() {
    if (stopRecordingPromise) return stopRecordingPromise;
    stopRecordingPromise = (async () => {
      if (!mediaStream && !recordingActive) {
        cleanupMedia();
        return;
      }

      try {
        const merged = mergeBuffers(recordedBuffers);
        const peak = computePeak(merged);
        if (!merged.length) {
          setState('idle', 'Idle');
          setStatus(`No mic frames captured from ${currentMicLabel}.`, true);
          return;
        }
        const sampleRate = audioContext?.sampleRate || 48000;
        const downsampled = downsampleBuffer(merged, sampleRate, 16000);
        const wavBlob = encodeWav(downsampled, 16000, 1, 16);
        const transcript = await transcribeWavBlob(wavBlob);
        const text = (transcript.text || '').trim();
        if (!text) {
          setState('idle', 'Idle');
          setStatus(`Didn't catch speech from ${currentMicLabel}. Peak ${peak.toFixed(3)}.`);
          return;
        }
        setTextareaValue(text);
        setState('idle', 'Idle');
        setStatus(`Transcript ready: ${text}`);
        if (settings.autoSend) {
          sendText(text);
          setStatus('Transcript sent to chat.');
        }
      } catch (error) {
        console.error(error);
        setState('idle', 'Idle');
        setStatus(String(error), true);
      } finally {
        cleanupMedia();
        recordingActive = false;
        sideButtonRecording = false;
        stopRecordingPromise = null;
      }
    })();
    return stopRecordingPromise;
  }

  function cleanupMedia() {
    if (processorNode) {
      try { processorNode.disconnect(); } catch {}
      processorNode.onaudioprocess = null;
      processorNode = null;
    }
    if (silentGainNode) {
      try { silentGainNode.disconnect(); } catch {}
      silentGainNode = null;
    }
    if (sourceNode) {
      try { sourceNode.disconnect(); } catch {}
      sourceNode = null;
    }
    if (audioContext) {
      audioContext.close().catch(() => {});
      audioContext = null;
    }
    if (mediaStream) {
      mediaStream.getTracks().forEach((track) => track.stop());
      mediaStream = null;
    }
    recordedBuffers = [];
    currentMicLabel = '';
  }

  async function speakLatest(force = true) {
    const payload = getLatestAssistantPayload();
    if (!payload) {
      setStatus('No assistant reply found yet.');
      return;
    }
    await speakText(payload.text, { force, key: payload.key });
  }

  function maybeAutoSpeak() {
    if (!settings.autoSpeak) return;
    clearTimeout(speakDebounce);
    speakDebounce = window.setTimeout(async () => {
      try {
        const payload = getLatestAssistantPayload();
        if (!payload || payload.key === lastSpokenKey) return;
        await speakText(payload.text, { key: payload.key });
      } catch (error) {
        console.error(error);
        setStatus(String(error), true);
      }
    }, 500);
  }

  function attachObserver() {
    const thread = document.querySelector('.chat-thread-inner') || document.querySelector('.chat-thread');
    if (!thread) return false;
    if (observer) observer.disconnect();
    observer = new MutationObserver(() => maybeAutoSpeak());
    observer.observe(thread, { childList: true, subtree: true, characterData: true });
    return true;
  }

  function setPanelMode(mode) {
    settings.panelMode = mode;
    saveSettings();
    updatePanelMode();
  }

  function updatePanelMode() {
    if (!panel) return;
    panel.classList.toggle('is-compact', settings.panelMode === 'compact');
    panel.classList.toggle('is-minimized', settings.panelMode === 'minimized');

    if (shrinkButton) {
      shrinkButton.textContent = settings.panelMode === 'compact' ? 'Restore' : 'Shrink';
      shrinkButton.title = settings.panelMode === 'compact' ? 'Restore full widget' : 'Shrink widget';
    }
    if (minimizeButton) {
      minimizeButton.textContent = settings.panelMode === 'minimized' ? 'Restore' : 'Minimize';
      minimizeButton.title = settings.panelMode === 'minimized' ? 'Restore widget' : 'Minimize widget';
    }
  }

  function createPanel() {
    if (document.getElementById(PANEL_ID)) return document.getElementById(PANEL_ID);

    const wrap = document.createElement('div');
    wrap.id = PANEL_ID;
    wrap.innerHTML = `
      <div class="hal-voice-card">
        <div class="hal-voice-row hal-voice-row--title">
          <strong>Hal Voice</strong>
          <div class="hal-voice-actions">
            <button type="button" data-action="speak-last">Speak last</button>
            <button type="button" data-action="stop-speaking">Stop</button>
            <button type="button" data-action="toggle-shrink">Shrink</button>
            <button type="button" data-action="toggle-minimize">Minimize</button>
          </div>
        </div>
        <div class="hal-voice-body">
          <div class="hal-voice-row hal-voice-row--state">
            <div id="${STATE_ID}" class="hal-voice-state" data-mode="idle">Idle</div>
            <div class="hal-voice-hotkey">PTT: ${HOTKEY_LABEL}</div>
          </div>
          <label class="hal-voice-label">Bridge URL
            <input type="text" data-field="bridgeUrl" placeholder="http://127.0.0.1:8765" />
          </label>
          <label class="hal-voice-label">Voice
            <input type="text" data-field="voice" placeholder="en_US-hal_6409-medium" />
          </label>
          <label class="hal-voice-check"><input type="checkbox" data-field="autoSpeak" /> Auto speak replies</label>
          <label class="hal-voice-check"><input type="checkbox" data-field="autoSend" /> Auto send transcripts</label>
          <div class="hal-voice-row hal-voice-row--ptt">
            <button type="button" data-action="ptt" class="hal-voice-ptt">Hold to talk (${HOTKEY_LABEL})</button>
          </div>
          <div id="${STATUS_ID}" class="hal-voice-status">Idle</div>
        </div>
      </div>
    `;

    const style = document.createElement('style');
    style.textContent = `
      #${PANEL_ID} {
        margin-right: 8px;
        display: flex;
        align-items: center;
      }
      #${PANEL_ID} .hal-voice-card {
        min-width: 250px;
        max-width: 320px;
        padding: 10px;
        border: 1px solid rgba(120, 140, 255, 0.35);
        border-radius: 10px;
        background: rgba(16, 20, 32, 0.92);
        color: #e8eeff;
        font: 12px/1.35 system-ui, sans-serif;
        box-shadow: 0 8px 24px rgba(0,0,0,0.25);
      }
      #${PANEL_ID}.is-compact .hal-voice-card {
        min-width: 220px;
        max-width: 220px;
      }
      #${PANEL_ID}.is-minimized .hal-voice-card {
        min-width: 170px;
        max-width: 170px;
        padding: 8px;
      }
      #${PANEL_ID} .hal-voice-row {
        display: flex;
        gap: 8px;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 8px;
      }
      #${PANEL_ID} .hal-voice-row--state {
        align-items: center;
      }
      #${PANEL_ID} .hal-voice-actions {
        display: flex;
        gap: 6px;
        flex-wrap: wrap;
        justify-content: flex-end;
      }
      #${PANEL_ID} .hal-voice-actions button,
      #${PANEL_ID} .hal-voice-ptt {
        cursor: pointer;
      }
      #${PANEL_ID} .hal-voice-label {
        display: block;
        margin-bottom: 8px;
      }
      #${PANEL_ID} input[type="text"] {
        width: 100%;
        margin-top: 4px;
        box-sizing: border-box;
        border-radius: 6px;
        border: 1px solid rgba(255,255,255,0.16);
        padding: 6px 8px;
        background: rgba(255,255,255,0.06);
        color: inherit;
      }
      #${PANEL_ID} .hal-voice-check {
        display: flex;
        align-items: center;
        gap: 8px;
        margin-bottom: 6px;
      }
      #${PANEL_ID} button {
        border: 1px solid rgba(255,255,255,0.16);
        border-radius: 6px;
        padding: 6px 10px;
        background: rgba(107, 130, 255, 0.18);
        color: inherit;
      }
      #${PANEL_ID} .hal-voice-state {
        padding: 4px 8px;
        border-radius: 999px;
        font-weight: 600;
        background: rgba(255,255,255,0.08);
        color: #dbe5ff;
      }
      #${PANEL_ID} .hal-voice-state[data-mode="idle"] { background: rgba(255,255,255,0.08); }
      #${PANEL_ID} .hal-voice-state[data-mode="listening"] { background: rgba(255, 94, 94, 0.22); color: #ffd6d6; }
      #${PANEL_ID} .hal-voice-state[data-mode="transcribing"] { background: rgba(255, 196, 87, 0.22); color: #ffe5ad; }
      #${PANEL_ID} .hal-voice-state[data-mode="speaking"] { background: rgba(109, 179, 255, 0.24); color: #d7eeff; }
      #${PANEL_ID} .hal-voice-hotkey {
        font-size: 11px;
        opacity: 0.8;
      }
      #${PANEL_ID} .hal-voice-ptt.recording {
        background: rgba(255, 94, 94, 0.22);
        border-color: rgba(255, 94, 94, 0.4);
      }
      #${PANEL_ID} .hal-voice-ptt.busy {
        background: rgba(255, 196, 87, 0.20);
        border-color: rgba(255, 196, 87, 0.35);
      }
      #${PANEL_ID} .hal-voice-status {
        min-height: 16px;
        color: #b7c9ff;
        white-space: normal;
        overflow-wrap: anywhere;
        word-break: break-word;
      }
      #${PANEL_ID}.is-compact .hal-voice-label,
      #${PANEL_ID}.is-compact .hal-voice-check,
      #${PANEL_ID}.is-compact .hal-voice-row--ptt {
        display: none;
      }
      #${PANEL_ID}.is-minimized .hal-voice-body {
        display: none;
      }
      #${PANEL_ID}.is-minimized .hal-voice-card {
        border-style: dashed;
      }
      @media (max-width: 900px) {
        #${PANEL_ID} {
          position: fixed;
          right: 12px;
          bottom: 12px;
          z-index: 9999;
        }
      }
    `;
    document.head.appendChild(style);

    const toolbarLeft = document.querySelector('.agent-chat__toolbar-left');
    if (toolbarLeft && toolbarLeft.parentElement) {
      toolbarLeft.parentElement.insertBefore(wrap, toolbarLeft.parentElement.firstChild);
    } else {
      wrap.style.position = 'fixed';
      wrap.style.right = '12px';
      wrap.style.bottom = '12px';
      wrap.style.zIndex = '9999';
      document.body.appendChild(wrap);
    }

    statusEl = wrap.querySelector(`#${STATUS_ID}`);
    stateEl = wrap.querySelector(`#${STATE_ID}`);
    pttButton = wrap.querySelector('[data-action="ptt"]');
    shrinkButton = wrap.querySelector('[data-action="toggle-shrink"]');
    minimizeButton = wrap.querySelector('[data-action="toggle-minimize"]');

    for (const field of ['bridgeUrl', 'voice']) {
      const input = wrap.querySelector(`[data-field="${field}"]`);
      input.value = settings[field] || '';
      input.addEventListener('change', () => {
        settings[field] = input.value.trim();
        saveSettings();
        setStatus('Saved.');
      });
    }

    for (const field of ['autoSpeak', 'autoSend']) {
      const input = wrap.querySelector(`[data-field="${field}"]`);
      input.checked = Boolean(settings[field]);
      input.addEventListener('change', () => {
        settings[field] = input.checked;
        saveSettings();
        setStatus('Saved.');
      });
    }

    wrap.querySelector('[data-action="speak-last"]').addEventListener('click', async () => {
      try {
        await speakLatest(true);
      } catch (error) {
        console.error(error);
        setStatus(String(error), true);
      }
    });

    wrap.querySelector('[data-action="stop-speaking"]').addEventListener('click', () => {
      stopPlayback(true);
    });

    shrinkButton.addEventListener('click', () => {
      setPanelMode(settings.panelMode === 'compact' ? 'full' : 'compact');
    });

    minimizeButton.addEventListener('click', () => {
      setPanelMode(settings.panelMode === 'minimized' ? 'full' : 'minimized');
    });

    const start = async (event) => {
      event.preventDefault();
      try {
        await startRecording();
      } catch (error) {
        console.error(error);
        recordingActive = false;
        sideButtonRecording = false;
        setState('idle', 'Idle');
        setStatus(String(error), true);
      }
    };

    const stop = (event) => {
      event.preventDefault();
      stopRecording().catch((error) => {
        console.error(error);
        setState('idle', 'Idle');
        setStatus(String(error), true);
      });
    };

    pttButton.addEventListener('mousedown', start);
    pttButton.addEventListener('mouseup', stop);
    pttButton.addEventListener('mouseleave', stop);
    pttButton.addEventListener('touchstart', start, { passive: false });
    pttButton.addEventListener('touchend', stop, { passive: false });
    pttButton.addEventListener('touchcancel', stop, { passive: false });

    panel = wrap;
    updatePanelMode();
    setState('idle', 'Idle');
    setStatus(`Ready. Hold the button or hold ${HOTKEY_LABEL} to talk.`);
    return wrap;
  }

  function hotkeyAllowed(event) {
    const target = event.target;
    if (!target) return true;
    if (target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement) return false;
    if (target instanceof HTMLElement && target.isContentEditable) return false;
    return true;
  }

  function installControls() {
    if (controlsInstalled) return;
    controlsInstalled = true;

    window.addEventListener('mousedown', (event) => {
      if (event.button !== MOUSE_SIDE_BUTTON || sideButtonRecording || !hotkeyAllowed(event)) return;
      sideButtonRecording = true;
      event.preventDefault();
      startRecording().catch((error) => {
        console.error(error);
        sideButtonRecording = false;
        recordingActive = false;
        setState('idle', 'Idle');
        setStatus(String(error), true);
      });
    }, true);

    window.addEventListener('mouseup', (event) => {
      if (event.button !== MOUSE_SIDE_BUTTON || !sideButtonRecording) return;
      sideButtonRecording = false;
      event.preventDefault();
      stopRecording().catch((error) => {
        console.error(error);
        setState('idle', 'Idle');
        setStatus(String(error), true);
      });
    }, true);

    window.addEventListener('auxclick', (event) => {
      if (event.button === MOUSE_SIDE_BUTTON) event.preventDefault();
    }, true);
  }

  function init() {
    panel = createPanel();
    attachObserver();
    maybeAutoSpeak();
    installControls();
  }

  function boot() {
    init();
    if (!pageObserver) {
      pageObserver = new MutationObserver(() => {
        if (!document.getElementById(PANEL_ID)) createPanel();
        if (!observer || !document.querySelector('.chat-thread-inner')) attachObserver();
      });
      pageObserver.observe(document.body, { childList: true, subtree: true });
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot, { once: true });
  } else {
    boot();
  }
})();
